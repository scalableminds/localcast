(function() {
  var Marionette, PlaylistItemView, PlaylistView, app, _,
    __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  _ = require("lodash");

  Marionette = require("backbone.marionette");

  app = require("../app.js");

  PlaylistItemView = require("./playlist_item_view");

  module.exports = PlaylistView = (function(_super) {
    __extends(PlaylistView, _super);

    function PlaylistView() {
      return PlaylistView.__super__.constructor.apply(this, arguments);
    }

    PlaylistView.prototype.template = _.template(" <table class=\"table\">\n  <thead>\n    <tr>\n      <th>Title</th>\n      <th>Duration</th>\n      <th></th>\n    </tr>\n  </thead>\n  <tbody></tbody>\n</table>");

    PlaylistView.prototype.className = "playlist full-height";

    PlaylistView.prototype.itemView = PlaylistItemView;

    PlaylistView.prototype.itemViewContainer = "tbody";

    PlaylistView.prototype.itemViewOptions = function() {
      return {
        parent: this
      };
    };

    PlaylistView.prototype.initialize = function() {
      this.activeTrack = 0;
      this.listenTo(app.vent, "controls:next", this.nextTrack);
      this.listenTo(app.vent, "controls:previous", this.previousTrack);
      this.listenTo(app.vent, "controls:play", this.playTrack);
      return this.listenTo(app.vent, "controls:progressEnd", this.nextTrack);
    };

    PlaylistView.prototype.nextTrack = function() {
      if (this.collection.length > 0 && this.activeTrack < this.collection.length - 1) {
        this.activeTrack++;
        return this.playTrack();
      }
    };

    PlaylistView.prototype.previousTrack = function() {
      if (this.collection.length > 0 && this.activeTrack > 0) {
        this.activeTrack--;
        return this.playTrack();
      }
    };

    PlaylistView.prototype.playTrack = function(model) {
      var track;
      if (model) {
        track = this.collection.get(model);
        this.activeTrack = this.collection.indexOf(model);
      } else {
        track = this.collection.at(this.activeTrack);
      }
      return app.vent.trigger("playlist:playTrack", track);
    };

    return PlaylistView;

  })(Marionette.CompositeView);

}).call(this);
