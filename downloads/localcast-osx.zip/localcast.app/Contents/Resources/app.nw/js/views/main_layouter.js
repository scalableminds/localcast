(function() {
  var Backbone, DeviceSelectionView, DragDropView, MainLayouter, Marionette, Notifications, PlayerControlsView, PlaylistCollection, PlaylistView, app, _,
    __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
    __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  _ = require("lodash");

  app = require("../app");

  Backbone = require("backbone");

  Marionette = require("backbone.marionette");

  PlaylistView = require("./playlist_view");

  DragDropView = require("./drag_drop_view");

  Notifications = require("./notification_view");

  PlayerControlsView = require("./player_controls_view");

  DeviceSelectionView = require("./device_selection_view");

  PlaylistCollection = require("../models/playlist_collection");

  module.exports = MainLayouter = (function(_super) {
    __extends(MainLayouter, _super);

    function MainLayouter() {
      this.fileDrop = __bind(this.fileDrop, this);
      return MainLayouter.__super__.constructor.apply(this, arguments);
    }

    MainLayouter.prototype.template = _.template("<section class=\"notification-container\"></section>\n<section class=\"content-container\"></section>\n<section class=\"modal-container\"></section>\n<section class=\"navbar-bottom\"></section>");

    MainLayouter.prototype.className = "container vbox";

    MainLayouter.prototype.regions = {
      "sectionContent": ".content-container",
      "sectionControls": ".navbar-bottom",
      "sectionModal": ".modal-container",
      "sectionNotifications": ".notification-container"
    };

    MainLayouter.prototype.events = {
      "drop": "fileDrop"
    };

    MainLayouter.prototype.initialize = function() {
      this.dragDropView = new DragDropView();
      this.playerControlsView = new PlayerControlsView();
      this.deviceSelectionView = new DeviceSelectionView();
      this.playlistCollection = new PlaylistCollection();
      this.playlistView = new PlaylistView({
        collection: this.playlistCollection
      });
      this.listenTo(this, "render", this.showRegions);
      return app.commands.execute("showCastDevices");
    };

    MainLayouter.prototype.showRegions = function() {
      this.sectionContent.show(this.dragDropView);
      this.sectionControls.show(this.playerControlsView);
      this.sectionModal.show(this.deviceSelectionView);
      return this.sectionNotifications.show(Notifications);
    };

    MainLayouter.prototype.fileDrop = function(evt) {
      var files;
      evt.preventDefault();
      files = evt.originalEvent.dataTransfer.files;
      _.map(files, (function(_this) {
        return function(file) {
          return _this.playlistCollection.add(file, {
            validate: true
          });
        };
      })(this));
      return this.sectionContent.show(this.playlistView);
    };

    return MainLayouter;

  })(Marionette.Layout);

}).call(this);
