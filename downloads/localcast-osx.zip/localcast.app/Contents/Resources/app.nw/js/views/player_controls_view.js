(function() {
  var Marionette, PlayerControlsView, Utils, app, _,
    __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  _ = require("lodash");

  Marionette = require("backbone.marionette");

  app = require("../app");

  Utils = require("../utils");

  module.exports = PlayerControlsView = (function(_super) {
    __extends(PlayerControlsView, _super);

    function PlayerControlsView() {
      return PlayerControlsView.__super__.constructor.apply(this, arguments);
    }

    PlayerControlsView.prototype.template = _.template("<div class=\"button-controls\">\n  <button class=\"btn btn-default previous\">\n    <span class=\"fa fa-backward fa-lg\"></span>\n  </button>\n  <button class=\"btn btn-default play\">\n    <span class=\"fa fa-play fa-2x\"></span>\n  </button>\n  <button class=\"btn btn-default next\">\n    <span class=\"fa fa-forward fa-lg\"></span>\n  </button>\n</div>\n<div class=\"hbox progress-controls flex-center\">\n  <span class=\"current-time\">00:00</span>\n  <div class=\"progress\">\n    <div class=\"progress-bar\" role=\"progressbar\" aria-valuenow=\"60\" aria-valuemin=\"0\" aria-valuemax=\"100\" style=\"width: 0%;\"></div>\n    <div class=\"progress-handle\"></div>\n  </div>\n  <span class=\"total-time\">00:00</span>\n</div>\n<div class=\"shuffle-cast\">\n  <!--<span class=\"fa fa-random fa-lg disabled\"></span>-->\n  <span class=\"icon-chromecast\"></span>\n</div>");

    PlayerControlsView.prototype.className = "hbox flex-center player-controls";

    PlayerControlsView.prototype.ui = {
      "playButton": ".play",
      "progressHandle": ".progress-handle",
      "progressBar": ".progress-bar",
      "progressContainer": ".progress",
      "totalTimeLabel": ".total-time",
      "currentTimeLabel": ".current-time"
    };

    PlayerControlsView.prototype.events = {
      "click @ui.playButton": "playPauseTrack",
      "click @ui.progressContainer": "seek",
      "click .next": "nextTrack",
      "click .previous": "previousTrack",
      "click .icon-chromecast": "showDevices"
    };

    PlayerControlsView.prototype.initialize = function() {
      this.listenTo(app.vent, "app:stateChanged", this.playPauseTrack);
      this.listenTo(app.vent, "chromecast:status", this.startProgress);
      this.timer = function() {
        return setTimeout((function(_this) {
          return function() {
            _this.trigger("tick", _this.lastTick);
            _this.lastTick = Date.now();
            return _this.timer();
          };
        })(this), 100);
      };
      return this.timer();
    };

    PlayerControlsView.prototype.playPauseTrack = function(arg) {
      var triggeredByEvent;
      triggeredByEvent = _.isNumber(arg);
      switch (app.state) {
        case app.IDLE:
          return app.vent.trigger("controls:play");
        case app.PLAYING:
          this.ui.playButton.find("span").addClass("fa-pause");
          this.ui.playButton.find("span").removeClass("fa-play");
          if (!triggeredByEvent) {
            return app.vent.trigger("controls:pause");
          }
          break;
        case app.PAUSED:
          this.ui.playButton.find("span").removeClass("fa-pause");
          this.ui.playButton.find("span").addClass("fa-play");
          if (!triggeredByEvent) {
            return app.vent.trigger("controls:continue");
          }
      }
    };

    PlayerControlsView.prototype.nextTrack = function() {
      return app.vent.trigger("controls:next");
    };

    PlayerControlsView.prototype.previousTrack = function() {
      return app.vent.trigger("controls:previous");
    };

    PlayerControlsView.prototype.startProgress = function(status) {
      if (status.media) {
        this.duration = status.media.duration * 1000;
      }
      this.currentTime = status.currentTime * 1000;
      this.ui.totalTimeLabel.text(Utils.msToHumanString(this.duration));
      this.ui.currentTimeLabel.text(Utils.msToHumanString(this.currentTime));
      this.stopListening(this, "tick", this.showProgress);
      return this.listenTo(this, "tick", this.showProgress);
    };

    PlayerControlsView.prototype.showProgress = function(lastTick, forceRender) {
      var offsetX;
      if (app.state === app.PLAYING || forceRender) {
        this.currentTime += Date.now() - lastTick;
        this.ui.currentTimeLabel.text(Utils.msToHumanString(this.currentTime));
        offsetX = 100 * this.currentTime / this.duration;
        offsetX += "%";
        this.ui.progressBar.width(offsetX);
        this.ui.progressHandle.css("left", offsetX);
      }
      if (this.currentTime >= this.duration && !app.isTranscoding) {
        app.vent.trigger("controls:progressEnd");
        return this.stopListening(this, "tick", this.showProgress);
      }
    };

    PlayerControlsView.prototype.seek = function(evt) {
      var offsetX;
      if (!(app.isTranscoding || app.state === app.IDLE)) {
        offsetX = evt.offsetX / this.ui.progressContainer.width();
        this.currentTime = offsetX * this.duration;
        app.vent.trigger("controls:seek", this.currentTime);
        this.stopListening(this, "tick", this.showProgress);
        return this.listenToOnce(this, "tick", function(lastTick) {
          return this.showProgress(lastTick, true);
        });
      }
    };

    PlayerControlsView.prototype.showDevices = function() {
      return app.commands.execute("showCastDevices");
    };

    return PlayerControlsView;

  })(Marionette.ItemView);

}).call(this);
