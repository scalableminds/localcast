(function() {
  var $, Marionette, PlaylistView, Utils, app, _,
    __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  _ = require("lodash");

  Marionette = require("backbone.marionette");

  app = require("../app");

  Utils = require("../utils");

  $ = require("jquery");

  module.exports = PlaylistView = (function(_super) {
    __extends(PlaylistView, _super);

    function PlaylistView() {
      return PlaylistView.__super__.constructor.apply(this, arguments);
    }

    PlaylistView.prototype.tagName = "<tr>";

    PlaylistView.prototype.template = _.template("<td>\n  <%= name %>\n  <% if(isActive) { %>\n    <span class=\"fa fa-volume-up\"></span>\n  <% } %>\n</td>\n<td><%= Utils.msToHumanString(duration) %></td>\n<td><i class=\"fa <% if (!isVideoCompatible || !isAudioCompatible){ %> fa-exclamation-circle <% } %>\" title=\"This file is incompatible with Chromecast. This file needs to be live-encoded. (EXPERIMENTAL)\"></td>");

    PlaylistView.prototype.templateHelpers = {
      Utils: Utils
    };

    PlaylistView.prototype.events = {
      "dblclick": "playTrack",
      "click": "selectTrack",
      "click": "clickOrDBClick"
    };

    PlaylistView.prototype.className = function() {
      var klass;
      klass = "";
      if (this.model.get("isActive")) {
        klass += "active ";
      }
      if (this.model.get("isSelected")) {
        klass += "selected";
      }
      return klass;
    };

    PlaylistView.prototype.initialize = function(options) {
      this.parent = options.parent;
      this.listenTo(app.vent, "playlist:playTrack", this.update);
      this.listenTo(this, "render", this.afterRender);
      this.listenTo(this.model, "change", this.render);
      return this.alreadyClicked = false;
    };

    PlaylistView.prototype.update = function(newTrack) {
      if (this.model.get("isActive")) {
        this.model.set("isActive", this.model === newTrack);
        return this.render();
      } else {
        this.model.set("isActive", this.model === newTrack);
        if (this.model.get("isActive")) {
          return this.render();
        }
      }
    };

    PlaylistView.prototype.playTrack = function() {
      this.selectTrack();
      return this.parent.playTrack(this.model);
    };

    PlaylistView.prototype.afterRender = function() {
      return this.$el.attr("class", _.result(this, "className"));
    };

    PlaylistView.prototype.selectTrack = function() {
      var oldModel;
      oldModel = this.parent.collection.at(this.parent.activeTrack);
      oldModel.set("isSelected", false);
      this.parent.activeTrack = this.parent.collection.indexOf(this.model);
      this.model.set("isSelected", true);
      return this.render();
    };

    PlaylistView.prototype.clickOrDBClick = function() {
      if (this.alreadyClicked) {
        this.playTrack();
        this.alreadyClicked = false;
        return clearTimeout(this.timeout);
      } else {
        this.timeout = setTimeout((function(_this) {
          return function() {
            _this.selectTrack();
            return _this.alreadyClicked = false;
          };
        })(this), 200);
        return this.alreadyClicked = true;
      }
    };

    return PlaylistView;

  })(Marionette.ItemView);

}).call(this);
