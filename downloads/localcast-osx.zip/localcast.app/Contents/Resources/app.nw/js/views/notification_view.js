(function() {
  var Backbone, Marionette, NotificationView, app, _,
    __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  _ = require("lodash");

  Marionette = require("backbone.marionette");

  Backbone = require("backbone");

  app = require("../app");

  require('backbone').$ = require("jquery");

  NotificationView = (function(_super) {
    __extends(NotificationView, _super);

    function NotificationView() {
      return NotificationView.__super__.constructor.apply(this, arguments);
    }

    NotificationView.prototype.TIMEOUT = 5000;

    NotificationView.prototype.template = _.template("<div>\n  <button type=\"button\" class=\"close pull-right\">&times;</button>\n  <% _.each(items, function(notification){ %>\n    <div class=\"notification-message <%= notification.type %>\" data-id=\"<%= notification.id %>\">\n      <span class=\"fa fa-2x <%= getIcon(notification) %> pull-left\"></span>\n      <p>\n        <%= notification.message %>\n      </p>\n    </div>\n    <% }) %>\n</div>");

    NotificationView.prototype.className = "notifications slide";

    NotificationView.prototype.events = {
      "click .close": "dismissAll"
    };

    NotificationView.prototype.templateHelpers = {
      getIcon: function(notification) {
        if (notification.type === "normal") {
          return "fa-info-circle";
        } else {
          return "fa-exclamation-triangle";
        }
      }
    };

    NotificationView.prototype.initialize = function() {
      this.collection = new Backbone.Collection();
      return this.id = 0;
    };

    NotificationView.prototype.error = function(message) {
      return this.show(message, "error");
    };

    NotificationView.prototype.show = function(message, type) {
      var notification;
      if (type == null) {
        type = "normal";
      }
      if (message) {
        notification = {
          message: message,
          type: type,
          id: this.id++
        };
        this.collection.add(notification);
        this.showNotification();
      }
    };

    NotificationView.prototype.showNotification = function() {
      this.render();
      this.$el.addClass("in");
      return setTimeout((function(_this) {
        return function() {
          return _this.removeNotification();
        };
      })(this), this.TIMEOUT);
    };

    NotificationView.prototype.removeNotification = function() {
      var firstModel;
      firstModel = this.collection.first();
      this.collection.remove(firstModel);
      if (this.collection.length > 0) {
        return this.$("[data-id='" + (firstModel.get('id')) + "']").fadeOut();
      } else {
        return this.dismissAll();
      }
    };

    NotificationView.prototype.close = function() {
      return this.$el.removeClass("in");
    };

    NotificationView.prototype.dismissAll = function() {
      this.collection.reset();
      this.render();
      return this.close();
    };

    return NotificationView;

  })(Marionette.ItemView);

  module.exports = new NotificationView();

}).call(this);
