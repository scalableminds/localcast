(function() {
  var $, Backbone, DeviceSelectionView, Marionette, Utils, app, _,
    __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  _ = require("lodash");

  Marionette = require("backbone.marionette");

  Backbone = require("backbone");

  $ = require("jquery");

  app = require("../app");

  Utils = require("../utils");

  module.exports = DeviceSelectionView = (function(_super) {
    __extends(DeviceSelectionView, _super);

    function DeviceSelectionView() {
      return DeviceSelectionView.__super__.constructor.apply(this, arguments);
    }

    DeviceSelectionView.prototype.template = _.template("<div class=\"header\">\n  <button type=\"button\" class=\"close\">&times;</button>\n  <h4 class=\"modal-title\">Select a casting device</h4>\n</div>\n<div class=\"body\">\n  <ul>\n  <% _.each(items, function(device){ %>\n    <li>\n      <a data-id=\"<%= device.id %>\" href=\"#\">\n        <span class=\"icon-chromecast\"></span>\n        <span class=\"device\"><%= device.friendlyName %></span>\n      </a>\n    </li>\n  <% }) %>\n  <% if (items.length == 0){ %>\n    <li>No casting device found.</li>\n  <% } %>\n  </ul>\n</div>");

    DeviceSelectionView.prototype.className = "device-selection fade";

    DeviceSelectionView.prototype.events = {
      "click .close": "close",
      "click a": "selectDevice"
    };

    DeviceSelectionView.prototype.initialize = function() {
      this.collection = new Backbone.Collection();
      this.listenTo(app.vent, "chromecast:device_found", this.addDeviceToCollection);
      this.listenTo(this.collection, "add", this.render);
      this.listenTo(this.collection, "render", this.render);
      return app.commands.setHandler("showCastDevices", this.showDeviceSelection.bind(this));
    };

    DeviceSelectionView.prototype.scanForDevices = function() {
      this.collection.reset();
      app.commands.execute("scanForDevices");
      return this.render();
    };

    DeviceSelectionView.prototype.addDeviceToCollection = function(device) {
      if (!this.collection.findWhere({
        friendlyName: device.friendlyName
      })) {
        return this.collection.add(device);
      }
    };

    DeviceSelectionView.prototype.showDeviceSelection = function() {
      this.scanForDevices();
      this.render();
      return this.show();
    };

    DeviceSelectionView.prototype.selectDevice = function(evt) {
      var deviceID, deviceModel;
      deviceID = $(evt.currentTarget).data("id");
      deviceModel = this.collection.findWhere({
        id: deviceID
      });
      app.commands.execute("useDevice", deviceModel.attributes);
      return this.close();
    };

    DeviceSelectionView.prototype.show = function() {
      this.$el.show();
      return _.defer((function(_this) {
        return function() {
          return _this.$el.addClass("in");
        };
      })(this));
    };

    DeviceSelectionView.prototype.close = function() {
      this.$el.removeClass("in");
      return setTimeout((function(_this) {
        return function() {
          return _this.$el.hide();
        };
      })(this), 150);
    };

    return DeviceSelectionView;

  })(Marionette.ItemView);

}).call(this);
