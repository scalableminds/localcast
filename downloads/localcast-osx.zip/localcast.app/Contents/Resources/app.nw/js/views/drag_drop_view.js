(function() {
  var $, DragDropView, Marionette, _,
    __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  Marionette = require("backbone.marionette");

  _ = require("lodash");

  $ = require("jquery");

  module.exports = DragDropView = (function(_super) {
    __extends(DragDropView, _super);

    function DragDropView() {
      return DragDropView.__super__.constructor.apply(this, arguments);
    }

    DragDropView.prototype.template = _.template("<div>\n  <span class=\"fa fa-4x fa-copy\"></span>\n  <p>Drag and Drop some media files to start</p>\n</div>");

    DragDropView.prototype.className = "drag-drop hbox flex-center full-height";

    DragDropView.prototype.initialize = function() {
      window.ondrop = function(evt) {
        evt.preventDefault();
        return false;
      };
      window.ondragover = function(evt) {
        evt.preventDefault();
        return false;
      };
      return $(window).on({
        dragover: this.fileHover.bind(this),
        dragend: this.fileDragEnd.bind(this)
      });
    };

    DragDropView.prototype.fileHover = function() {
      return this.$el.addClass("hover");
    };

    DragDropView.prototype.fileDragEnd = function() {
      return this.$el.removeClass("hover");
    };

    DragDropView.prototype.onClose = function() {};

    return DragDropView;

  })(Marionette.ItemView);

}).call(this);
