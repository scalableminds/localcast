(function() {
  var Backbone, Compatibility, MediaFileModel, Notification, app,
    __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    __indexOf = [].indexOf || function(item) { for (var i = 0, l = this.length; i < l; i++) { if (i in this && this[i] === item) return i; } return -1; };

  Backbone = require("Backbone");

  app = require("../app");

  Compatibility = require("../compatibility");

  Notification = require("../views/notification_view");

  module.exports = MediaFileModel = (function(_super) {
    __extends(MediaFileModel, _super);

    function MediaFileModel() {
      return MediaFileModel.__super__.constructor.apply(this, arguments);
    }

    MediaFileModel.prototype.MEDIA_WHITELIST = ["image/jpeg", "image/png", "image/gif", "image/webp", "image/bmp", "video/mp4", "video/avi", "video/mkv", "video/webm", "audio/ogg", "audio/mp3", "audio/acc", "audio/vorbis"];

    MediaFileModel.prototype.defaults = {
      duration: 15000,
      isActive: false,
      isSelected: false,
      isVideoCompatible: true,
      isAudioCompatible: true
    };

    MediaFileModel.prototype.validate = function(file, options) {
      var _ref;
      file.type = this.determineMIMEType(file) || file.type;
      if (_ref = file.type, __indexOf.call(this.MEDIA_WHITELIST, _ref) < 0) {
        Notification.error("" + file.name + " is unsupported!");
        return Error("Unsupported Media File");
      }
    };

    MediaFileModel.prototype.initialize = function(file) {
      if (!this.get("type")) {
        this.determineMIMEType(file);
      }
      switch (this.get("type").split("/")[0]) {
        case "image":
          this.set("streamType", "NONE");
          return this.set("duration", 15000);
        case "video":
          this.set("streamType", "BUFFERED");
          return this.checkCompatibility();
        case "audio":
          return this.set("streamType", "BUFFERED");
      }
    };

    MediaFileModel.prototype.checkCompatibility = function() {
      if (app.hasFFmpegSupport) {
        return Compatibility.probe(this, this.set.bind(this));
      } else {
        switch (this.get("type").split("/")[1]) {
          case "webm":
            break;
          case "mkv":
          case "avi":
          case "mp4":
        }
      }
    };

    MediaFileModel.prototype.determineMIMEType = function(file) {
      var MIMEType, fileExtension;
      fileExtension = file.path.match(/\.(.{2,4})$/)[1];
      MIMEType = (function() {
        switch (fileExtension) {
          case "mkv":
            return "video/mkv";
        }
      })();
      if (MIMEType) {
        this.set("type", MIMEType);
      }
      return MIMEType;
    };

    return MediaFileModel;

  })(Backbone.Model);

}).call(this);
