(function() {
  var Backbone, MediaFileModel, PlaylistCollection,
    __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  Backbone = require("backbone");

  MediaFileModel = require("./media_file_model");

  module.exports = PlaylistCollection = (function(_super) {
    __extends(PlaylistCollection, _super);

    function PlaylistCollection() {
      return PlaylistCollection.__super__.constructor.apply(this, arguments);
    }

    PlaylistCollection.prototype.model = MediaFileModel;

    return PlaylistCollection;

  })(Backbone.Collection);

}).call(this);
