(function() {
  var Backbone, Notification, Server, app, express, ffmpeg, http, ip, portscanner, _;

  http = require("http");

  express = require("express");

  ip = require("ip");

  _ = require("lodash");

  Backbone = require("backbone");

  portscanner = require("portscanner");

  app = require("./app");

  ffmpeg = require("fluent-ffmpeg");

  Notification = require("./views/notification_view");

  Server = (function() {
    Server.prototype.port = 9090;

    function Server() {
      _.extend(this, Backbone.Events);
      this.listenTo(app.vent, "playlist:playTrack", function(file) {
        return this.file = file;
      });
      this.path = null;
      portscanner.findAPortNotInUse(this.port, this.port + 1000, '127.0.0.1', (function(_this) {
        return function(err, port) {
          var server;
          _this.port = port;
          server = express();
          server.use(function(err, req, res, next) {
            console.error(err);
            return res.send(500);
          });
          server.get("/chromecast/:cachebuster", function(req, res, next) {
            if (_this.file) {
              if (_this.file.get("isVideoCompatible") && _this.file.get("isAudioCompatible")) {
                res.sendfile(_this.file.get("path"));
                return app.isTranscoding = false;
              } else {
                if (app.hasFFmpegSupport) {
                  Notification.error("You are trying to play back an unsupported file. We will try to live-encode this for you. (EXPERIMENTAL) This is very computational expensive.");
                  _this.transcode(res);
                  return app.isTranscoding = true;
                } else {
                  Notification.error("Your file format may be unsupported by the Chromecast. Check our website for workarounds. We will try to play it anyway.");
                  app.isTranscoding = false;
                  return res.sendfile(_this.file.get("path"));
                }
              }
            }
          });
          return server.listen(_this.port);
        };
      })(this));
    }

    Server.prototype.getServerUrl = function() {
      console.log("http://" + (ip.address()) + ":" + this.port);
      return "http://" + (ip.address()) + ":" + this.port;
    };

    Server.prototype.transcode = function(res) {
      var proc;
      proc = new ffmpeg(this.file.get("path"));
      proc.toFormat("matroska");
      if (this.file.get("isVideoCompatible")) {
        proc.videoCodec("copy");
      } else {
        proc.videoCodec("libx264");
        proc.addOptions(["-profile:v high", "-level 5.0"]);
      }
      if (this.file.get("isAudioCompatible")) {
        proc.audioCodec("copy");
      } else {
        proc.audioCodec("aac");
        proc.audioQuality(100);
      }
      proc.on('start', function(commandLine) {
        return console.log('Spawned Ffmpeg with command: ' + commandLine);
      }).on('error', function(err) {
        return console.log('an error happened: ' + err.message, err);
      });
      return proc.pipe(res, {
        end: true
      });
    };

    return Server;

  })();

  module.exports = new Server();

}).call(this);
