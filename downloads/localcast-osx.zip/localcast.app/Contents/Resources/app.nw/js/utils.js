(function() {
  var Utils;

  module.exports = Utils = {
    msToHumanString: function(ms) {
      var hours, minutes, seconds;
      seconds = Math.floor((ms / 1000) % 60);
      minutes = Math.floor(ms / 1000 / 60);
      if (minutes < 60) {
        return "" + (this.zeroPadded(minutes)) + ":" + (this.zeroPadded(seconds));
      } else {
        hours = Math.floor(minutes / 60);
        minutes = minutes % 60;
        return "" + (this.zeroPadded(hours)) + ":" + (this.zeroPadded(minutes)) + ":" + (this.zeroPadded(seconds));
      }
    },
    zeroPadded: function(number) {
      var string;
      string = number.toString();
      if (string.length === 1) {
        string = "0" + string;
      }
      return string;
    }
  };

}).call(this);
