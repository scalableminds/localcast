(function() {
  var ffmpeg;

  ffmpeg = require("fluent-ffmpeg");

  module.exports = {
    cache: {},
    probe: function(file, cb) {
      var filePath, value;
      filePath = file.get("path");
      if (value = this.cache[filePath]) {
        return cb(value);
      } else {
        return ffmpeg.ffprobe(filePath, (function(_this) {
          return function(err, probeData) {
            var result;
            if (!err) {
              result = {
                isVideoCompatible: _this.isVideoCompatible(probeData),
                isAudioCompatible: _this.isAudioCompatible(probeData),
                duration: _this.duration(probeData)
              };
              _this.cache[filePath] = result;
              return cb(result);
            }
          };
        })(this));
      }
    },
    isVideoCompatible: function(probeData) {
      var isCompatible;
      isCompatible = false;
      probeData.streams.forEach(function(stream) {
        if (stream.codec_type === "video") {
          if (stream.codec_name === "h264" && (stream.profile === "High" || stream.profile === "Main") && (stream.level === 31 || stream.level === 40 || stream.level === 41 || stream.level === 42 || stream.level === 5 || stream.level === 50 || stream.level === 51)) {
            return isCompatible = true;
          } else if (stream.codec_name === "vp8") {
            return isCompatible = true;
          }
        }
      });
      return isCompatible;
    },
    isAudioCompatible: function(probeData) {
      var isCompatible;
      isCompatible = false;
      probeData.streams.forEach(function(stream) {
        if (stream.codec_type === "audio") {
          if (stream.codec_name === "aac" || stream.codec_name === "mp3" || stream.codec_name === "vorbis" || stream.codec_name === "opus") {
            return isCompatible = true;
          }
        }
      });
      return isCompatible;
    },
    duration: function(probeData) {
      return probeData.format.duration * 1000;
    }
  };

}).call(this);
