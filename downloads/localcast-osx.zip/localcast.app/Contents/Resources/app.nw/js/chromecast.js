(function() {
  var Backbone, Chromecast, Notification, app, nodecastor, server, _,
    __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  nodecastor = require("nodecastor");

  Backbone = require("backbone");

  _ = require("lodash");

  app = require("./app");

  server = require("./server");

  Notification = require("./views/notification_view");

  module.exports = Chromecast = (function() {
    Chromecast.prototype.DEFAULT_MEDIA_RECEIVER = "CC1AD845";

    Chromecast.prototype.MEDIA_NAMESPACE = "urn:x-cast:com.google.cast.media";

    function Chromecast() {
      this.requestSession = __bind(this.requestSession, this);
      _.extend(this, Backbone.Events);
      this.listenTo(app.vent, "playlist:playTrack", this.playMedia);
      this.listenTo(app.vent, "controls:pause", this.pause);
      this.listenTo(app.vent, "controls:continue", this.play);
      this.listenTo(app.vent, "controls:seek", this.seek);
      app.commands.setHandler("useDevice", this.connect.bind(this));
      app.commands.setHandler("scanForDevices", this.scan);
      this.requestId = 0;
    }

    Chromecast.prototype.scan = function() {
      return nodecastor.scan().on("online", (function(_this) {
        return function(device) {
          device.on("error", function(err) {
            console.error(err);
            return app.vent.trigger("chromecast:device_disconnected", device);
          });
          return app.vent.trigger("chromecast:device_found", device);
        };
      })(this)).on("offline", function(device) {
        return console.log("Removed device", device);
      }).on("error", function(err) {
        return console.error(err);
      }).start();
    };

    Chromecast.prototype.connect = function(device) {
      if (device === this.device) {
        return;
      }
      if (app.isCasting) {
        app.isCasting = false;
        this.stop();
      }
      this.device = new nodecastor.CastDevice(device);
      this.device.on("disconnect", function() {
        return console.log(arguments);
      });
      return this.device.on("connect", (function(_this) {
        return function() {
          _this.device.status(function(err, s) {
            if (!err) {
              return console.log("Chromecast status", s);
            }
          });
          _this.device.on("status", function(status) {
            return console.log("Chromecast status updated", status);
          });
          return _this.device.application(_this.DEFAULT_MEDIA_RECEIVER, function(err, receiver_app) {
            if (!err) {
              if (app.isCasting) {
                return receiver_app.join(_this.MEDIA_NAMESPACE, _this.requestSession);
              } else {
                return receiver_app.run(_this.MEDIA_NAMESPACE, _this.requestSession);
              }
            }
          });
        };
      })(this));
    };

    Chromecast.prototype.requestSession = function(err, session) {
      if (!err) {
        this.session = session;
        return app.isCasting = true;
      }
    };

    Chromecast.prototype.disconnect = function() {
      if (this.device) {
        this.stop();
        return this.device.stop();
      }
    };

    Chromecast.prototype.playMedia = function(file) {
      var mediaInfo, request;
      if (this.device && this.session && file) {
        app.changeState(app.PLAYING);
        mediaInfo = {
          contentId: "" + (server.getServerUrl()) + "/chromecast/" + (Date.now()),
          streamType: file.get("streamType"),
          contentType: file.get("type")
        };
        request = {
          type: "LOAD",
          media: mediaInfo
        };
        this.mediaSessionId = null;
        return this.sendCommand(request);
      }
    };

    Chromecast.prototype.seek = function(time) {
      var request;
      request = {
        type: "SEEK",
        currentTime: time / 1000
      };
      return this.sendCommand(request);
    };

    Chromecast.prototype.play = function() {
      var request;
      app.changeState(app.PLAYING);
      request = {
        type: "PLAY"
      };
      return this.sendCommand(request);
    };

    Chromecast.prototype.pause = function() {
      var request;
      app.changeState(app.PAUSED);
      request = {
        type: "PAUSE"
      };
      return this.sendCommand(request);
    };

    Chromecast.prototype.stop = function() {
      var request;
      app.changeState(app.IDLE);
      request = {
        type: "STOP"
      };
      return this.sendCommand(request);
    };

    Chromecast.prototype.sendCommand = function(request) {
      if (this.session) {
        request = _.extend(request, {
          mediaSessionId: this.mediaSessionId,
          requestId: this.requestId++
        });
        console.log("COMMAND ", request);
        return this.session.send(request, this.handleCastResponse.bind(this));
      }
    };

    Chromecast.prototype.handleCastResponse = function(err, message) {
      var status;
      if (err) {
        console.error("Unable to cast:", err.message);
        this.device.stop();
      }
      if (message) {
        if (message.type === "MEDIA_STATUS") {
          status = message.status[0];
          this.mediaSessionId = status.mediaSessionId;
          Notification.show("Media Status: " + status.playerState);
          app.vent.trigger("chromecast:status", status);
        }
      }
      return console.log("RESPONSE ", message);
    };

    return Chromecast;

  })();

}).call(this);
